# HackFB
Hack FB With Multi ways

<ul>
<li><code>git clone https://github.com/justahackers/hackfb </code></li>
<li><code>cd hackfb </code><li>
<li><code>bash setup </code></li>
</ul>
<br />
